
package tareravacaciones;

import java.util.Scanner;


public class FuncionSumarDIgitos {
     public static int sumarDigitos(int numero) {
        int suma = 0;
        while (numero != 0) {
            suma += numero % 10;
            numero /= 10;
        }
        return suma;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num;
        do {
            System.out.print("Ingrese un número (o cero para terminar): ");
            num = sc.nextInt();
            if (num != 0) {
                int suma = sumarDigitos(num);
                System.out.printf("La suma de los dígitos de %d es: %d%n", num, suma);
            }
        } while (num != 0);
    }
}
